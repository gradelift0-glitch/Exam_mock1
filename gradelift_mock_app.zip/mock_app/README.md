# Gradelift Upper Limb Mock Exam

60 questions, 50 minutes, no login, unlimited retakes.

## Easiest setup (link only)
1. Upload `Gradelift_Mock_Exam_Questions.xlsx` to Google Drive and open it as a Google Sheet. Keep the tab names unchanged.
2. Share > General access > **Anyone with the link** > **Viewer**.
3. Push this folder to GitHub.
4. share.streamlit.io: New app, pick the repo, main file `app.py`. In Advanced settings > Secrets paste one line:
   `sheet_url = "https://docs.google.com/spreadsheets/d/YOUR_ID/edit"`
5. Check tab says READY, then share the app link.

Note: anyone who gets the Sheet link can see the answers. Keep the link private (it only lives in Streamlit Secrets).

## Private option (service account)
Use `gcp_service_account` + `sheet_id` secrets instead (see git history / ask Claude). The app uses this automatically when `sheet_url` is absent.

## Notes
- Timer is Settings!B4 (50 min). Auto-submits at zero. Refreshing restarts the exam.
- Question edits show up within about 10 minutes.
- Local test: `MOCK_LOCAL_XLSX=file.xlsx streamlit run app.py`
